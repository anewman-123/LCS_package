#' Brute-force approach for finding the longest common substring of two nucleotide sequences.
#' 
#' @param str1 First input sequence.
#' @param str2 Second input sequence.
#' 
#' @return Longest common substring of the two input strings.
#' 
#' @importFrom Rdpack reprompt
#' @references https://en.wikipedia.org/wiki/Longest_common_substring_problem
#' 
#' @examples
#' require(lcsPackage)
#' x1 <- 'ABCD'
#' x2 <- 'BCAA'
#' print(findLCS_simple(x1, x2))
#' 
#' @export
findLCS_simple <- function(str1, str2){
  ans = 0
  idx = 0 
  new_idx = 0
  for (i in 1:nchar(str1)){         
    for (j in 1:nchar(str2)){
      k = 0
      while ((i + k) <= nchar(str1) && 
             (j + k) <= nchar(str2) && 
             substr(str1, i+k, i+k) == substr(str2, j+k, j+k)){
        k = k + 1
        idx = i
      }
      #ans = max(ans, k)
      if (ans < k){
        new_idx = i
        ans = k
      }
      
    }
  }
  return(substr(str1,new_idx,new_idx+ans-1))
}

#' Dynamic programming approach for finding the longest common substring of two nucleotide sequences.
#' 
#' @param s1 First input sequence.
#' @param s2 Second input sequence.
#' 
#' @return Longest common substring of the two input strings.
#' 
#' @importFrom Rdpack reprompt
#' @references https://en.wikipedia.org/wiki/Longest_common_substring_problem
#' 
#' @examples
#' require(lcsPackage)
#' x1 <- 'ABCD'
#' x2 <- 'BCAA'
#' print(findLCS_dp(x1, x2))
#' 
#' @export
#
findLCS_dp <- function(s1, s2) {
  #store length of each string
  len1 <- nchar(s1)
  len2 <- nchar(s2)
  
  #create a DP matrix 
  dp_matrix <- matrix(nrow = len1 + 1, ncol = len2 + 1)
  
  #store length of lcs
  length <- 0
  
  #loop through both sets of strings
  for (i in 1:(len1 + 1)) {
    for (j in 1:(len2 + 1)) {
      #fill in the necessary zeros for the matrix (i.e. index isn't in the string)
      if (i == 1 || j == 1) {
        dp_matrix[i, j] = 0
      }
      #if two strings have the same value, store matrix value as one plus the value in the upper left diagonal in the matrix  
      else if (substr(s1, i - 1, i - 1) == substr(s2, j - 1, j - 1)) { 
        dp_matrix[i, j] = dp_matrix[i-1, j-1] + 1
      }
      #if two strings don't have the same value, store matrix value as zero
      else {
        dp_matrix[i, j] = 0
      }
    }
  }
  
  #store length of lcs as maximum value from the DP matrix
  length <- max(dp_matrix)
  
  #create an empty vector for lcs
  lcs <- c()
  
  #find indices in DP matrix that yield maximum values
  max_pos <- which(dp_matrix == max(dp_matrix), arr.ind = TRUE)
  
  #get rid of column names and need to subtract one (made DP matrix one size too big)
  colnames(max_pos) <- NULL
  max_pos <- max_pos - 1
  
  #find each lcs that yields the maximum length lcs
  for (row in 1:nrow(max_pos)) {
    lcs[row] <- substr(s1, max_pos[row, 1] - length + 1, max_pos[row, 1])
  }
  #return the lcs vector (there can be more than one)
  return(lcs)
}

#' Recursive function for finding the longest common subsequence of two nucleotide sequences.
#' 
#' @param s1 First input sequence.
#' @param s2 Second input sequence.
#' 
#' @return Longest common subsequence of the two input strings.
#' 
#' @importFrom Rdpack reprompt
#' @references https://en.wikipedia.org/wiki/Longest_common_subsequence_problem
#' 
#' @examples
#' require(lcsPackage)
#' x1 <- 'ABCD'
#' x2 <- 'BCAA'
#' print(find_lcseqRec(x1, x2))
#' 
#' @export
#function that recursively solves for longest common subsequence
find_lcseqRec <- function(s1, s2) {
  return(find_lcseq_helper(s1, s2))
}

#' Helper for recursive function for finding the longest common subsequence of two nucleotide sequences.
#' 
#' @param s1 First input sequence.
#' @param s2 Second input sequence.
#' 
#' @return Longest common subsequence of the two input strings.
#' 
#' @importFrom Rdpack reprompt
#' @references https://en.wikipedia.org/wiki/Longest_common_subsequence_problem
#' 
#' @examples
#' require(lcsPackage)
#' x1 <- 'ABCD'
#' x2 <- 'BCAA'
#' print(find_lcseq_helper(x1, x2))
#' 
#' @export
find_lcseq_helper <- function(s1, s2) {
  
  #set the lengths of the strings
  len1 <- nchar(s1)
  len2 <- nchar(s2)
  
  #finish if you traverse through either string
  if (len1 == 0 || len2 == 0) {
    return("")
  }
  
  #return matching character and move down the strings
  else if (substr(s1, len1, len1) == substr(s2, len2, len2)) {
    return(paste(find_lcseq_helper(substr(s1, 1, len1 - 1), substr(s2, 1, len2 - 1)),
                 substr(s1, len1, len1), sep = ""))
  }
  
  #determine if it's optimal to move down string 1 or string 2
  else {
    new_s1 <- find_lcseq_helper(s1, substr(s2, 1, len2 - 1))
    new_s2 <- find_lcseq_helper(substr(s1, 1, len1 - 1), s2)
    if (nchar(new_s1) > nchar(new_s2)) {
      return(new_s1)
    }
    else {
      return(new_s2)
    }
  }
}

#' Dynamic programming for finding the longest common subsequence of two nucleotide sequences.
#' 
#' @param s1 First input sequence.
#' @param s2 Second input sequence.
#' 
#' @return Longest common subsequence of the two input strings.
#' 
#' @importFrom Rdpack reprompt
#' @references https://en.wikipedia.org/wiki/Longest_common_subsequence_problem
#' 
#' @examples
#' require(lcsPackage)
#' x1 <- 'ABCD'
#' x2 <- 'BCAA'
#' print(find_lcseqDp(x1, x2))
#' 
#' @export

find_lcseqDp <- function(s1, s2) {
  #store length of each string
  len1 <- nchar(s1)
  len2 <- nchar(s2)
  
  #create a DP matrix 
  dp_matrix <- matrix(nrow = len1 + 1, ncol = len2 + 1)
  
  #store length of lcs
  length <- 0
  
  #loop through both sets of strings
  for (i in 1:(len1 + 1)) {
    for (j in 1:(len2 + 1)) {
      #fill in the necessary zeros for the matrix (i.e. index isn't in the string)
      if (i == 1 || j == 1) {
        dp_matrix[i, j] = 0
      }
      #if two strings have the same value, store matrix value as one plus the value in the upper left diagonal in the matrix  
      else if (substr(s1, i - 1, i - 1) == substr(s2, j - 1, j - 1)) { 
        dp_matrix[i, j] = dp_matrix[i-1, j-1] + 1
      }
      #if two strings don't have the same value, store matrix value as zero
      else {
        dp_matrix[i, j] = max(dp_matrix[i-1, j-1], dp_matrix[i-1, j], dp_matrix[i, j-1])
      }
    }
  }
  
  #store length of lcs as maximum value from the DP matrix
  length <- max(dp_matrix)
  
  #create an empty vector for lcs
  lcs <- c()
  
  #find indices in DP matrix that yield maximum values
  max_pos <- which(dp_matrix == max(dp_matrix), arr.ind = TRUE)
  
  #get rid of column names 
  colnames(max_pos) <- NULL
  
  #start at index in DP matrix that yields maximum value
  i <- max_pos[1,1]
  j <- max_pos[1,2]
  
  #back trace to find the lcs
  while (i > 1 && j > 1) {
    if (dp_matrix[i, j-1] == dp_matrix[i-1, j]) {
      #append to lcs if the upper left diagonal value is higher than current position
      if (dp_matrix[i-1, j-1] < dp_matrix[i, j]) {
        lcs <- append(lcs, substr(s1, i-1, i-1))
      }
      #move current position to upper left diagonal
      i = i - 1
      j = j - 1
    }
    else {
      #move current up since it is greater than value to the left of current position
      if (dp_matrix[i, j-1] < dp_matrix[i-1, j]) {
        i = i - 1
      }
      #move current position to the left since it is greater than value above current position 
      else if (dp_matrix[i - 1, j] < dp_matrix[i, j - 1]) {
        j = j - 1
      }
    }
  }
  #turn vector into a string and reverse it, return the lcs
  return(lcs <- paste(rev(lcs), collapse = ""))
}